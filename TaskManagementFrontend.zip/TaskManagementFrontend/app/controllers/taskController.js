angular.module('taskApp').controller('TaskController', function($scope, TaskService) {
    $scope.tasks = [];
    $scope.newTask = {};

    $scope.loadTasks = function() {
        TaskService.getAllTasks().then(function(response) {
            $scope.tasks = response.data;
        });
    };

    $scope.addTask = function() {
        TaskService.addTask($scope.newTask).then(function() {
            $scope.loadTasks();
            $scope.newTask = {};
        });
    };

    $scope.editTask = function(task) {
        $scope.newTask = angular.copy(task);
    };

    $scope.deleteTask = function(id) {
        TaskService.deleteTask(id).then(function() {
            $scope.loadTasks();
        });
    };

    $scope.loadTasks();
});
