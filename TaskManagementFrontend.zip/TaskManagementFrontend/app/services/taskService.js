angular.module('taskApp').service('TaskService', function($http) {
    this.getAllTasks = function() {
        return $http.get('http://localhost:8080/api/tasks');
    };

    this.addTask = function(task) {
        return $http.post('http://localhost:8080/api/tasks', task);
    };

    this.updateTask = function(id, task) {
        return $http.put(`http://localhost:8080/api/tasks/${id}`, task);
    };

    this.deleteTask = function(id) {
        return $http.delete(`http://localhost:8080/api/tasks/${id}`);
    };
});
